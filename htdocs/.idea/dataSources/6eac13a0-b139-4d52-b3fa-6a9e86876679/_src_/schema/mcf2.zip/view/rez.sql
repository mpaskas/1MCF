CREATE VIEW `rez` AS
  SELECT
    `mcf2`.`rezervacija`.`brrezervacije` AS `brrezervacije`,
    `mcf2`.`rezervacija`.`tip`           AS `tip`,
    `mcf2`.`rezervacija`.`kolicina`      AS `kolicina`
  FROM (`mcf2`.`rezervacija`
    JOIN `mcf2`.`veza` ON ((`mcf2`.`veza`.`brr` = `mcf2`.`rezervacija`.`brrezervacije`)))